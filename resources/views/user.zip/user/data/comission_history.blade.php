@extends('user.layout.layout')
@section('content')
<!-- Statistics For User Rewards Start-->
<div class="notika-status-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="search-engine-int sm-res-mg-t-30 tb-res-mg-t-30 tb-res-ds-n dk-res-ds">
                    <div class="contact-hd search-hd-eg">
                        <h2>Comission History</h2>
                        <p>Members Refferal Income </p>
                    </div>
                    <div class="search-eg-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No#</th>
                                    <th>Comission ID</th>
                                    <th>Amount</th>
                                    <th>Member ID</th>
                                    <th>Member Name</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>01</td>
                                    <td>03</td>
                                    <td>
                                        <button class="btn btn-success notika-btn-success btn-xs waves-effect">$100.88</button>
                                    </td>
                                    <td>10</td>
                                    <td>Arslan Saleem</td>
                                    <td>25-Mar-2020</td>
                                </tr>
                                <tr>
                                    <td>01</td>
                                    <td>03</td>
                                    <td>
                                        <button class="btn btn-success notika-btn-success btn-xs waves-effect">$100.88</button>
                                    </td>
                                    <td>10</td>
                                    <td>Arslan Saleem</td>
                                    <td>25-Mar-2020</td>
                                </tr>
                                <tr>
                                    <td>01</td>
                                    <td>03</td>
                                    <td>
                                        <button class="btn btn-success notika-btn-success btn-xs waves-effect">$10.00</button>
                                    </td>
                                    <td>10</td>
                                    <td>Arslan Saleem</td>
                                    <td>25-Mar-2020</td>
                                </tr>
                                <tr>
                                    <td>04</td>
                                    <td>09</td>
                                    <td>
                                        <button class="btn btn-success notika-btn-success btn-xs waves-effect">$150.88</button>
                                    </td>
                                    <td>15</td>
                                    <td>Arslan Gujjar</td>
                                    <td>26-Mar-2020</td>
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Statistics For User Rewards End-->
@endsection