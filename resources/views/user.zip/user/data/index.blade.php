@extends('user.layout.layout')
@section('content')

<!-- Breadcomb area Start-->
<div class="breadcomb-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="breadcomb-list">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="breadcomb-wp">
                                <div class="breadcomb-icon">
                                    <i class="notika-icon notika-windows"></i>
                                </div>
                                <div class="breadcomb-ctn">
                                    <h2>Your Reference ID : <span  id="myInput"> URPIXPAYS999 </span></h2>
                                    <p>Share your Reference ID And Earn Refferal Rewards </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-3">
                            <div class="breadcomb-report">
                                <!-- <button data-toggle="tooltip" data-placement="left" title="Download Report" class="btn"><i class="notika-icon notika-sent"></i></button> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Breadcomb area End-->

<!-- Statistics For User Rewards Start-->
<div class="visitor-sv-tm-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="search-engine-int sm-res-mg-t-30 tb-res-mg-t-30 tb-res-ds-n dk-res-ds">
                    <div class="contact-hd search-hd-eg">
                        <h2>Your Refferal Rewards</h2>
                        <p>Here is the Rewards Earning </p>
                    </div>
                    <div class="search-eg-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User Name</th>
                                    <th>Level</th>
                                    <th>Date</th>
                                    <th class="text-right">Earning</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Arslan Saleem</td>
                                    <td>Level 2</td>
                                    <td>25-Mar-2020</td>
                                    <td class="text-right">
                                        <h4>$ 05</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Aqib Saeed</td>
                                    <td>Level 3</td>
                                    <td>27-Mar-2020</td>
                                    <td class="text-right">
                                        <h4>$ 03</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Kashan Ahsan</td>
                                    <td>Level 2</td>
                                    <td>27-Mar-2020</td>
                                    <td class="text-right">
                                        <h4>$ 04</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td>Asim Rasheed</td>
                                    <td>Level 3</td>
                                    <td>28-Mar-2020</td>
                                    <td class="text-right">
                                        <h4>$ 03</h4>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Statistics For User Rewards End-->
@endsection