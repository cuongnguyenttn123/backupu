@extends('user.layout.layout')
@section('content')
<div class="notika-status-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="form-example-wrap mg-t-30">
                    <div class="cmp-tb-hd cmp-int-hd">
                        <h2>Your Wallet Balance : <span class="text-info">$50.56</span> </h2>
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-example-int form-example-st">
                                <div class="form-group">
                                    <div class="nk-int-st">
                                        <input type="text" class="form-control input-sm" name="amount" placeholder="Enter Amount">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                            <div class="form-example-int form-example-st">
                                <div class="form-group">
                                    <div class="nk-int-st">
                                        <input type="text" class="form-control input-sm" placeholder="Password">
                                    </div>
                                </div>
                            </div>
                        </div> -->
                        <div class="col-lg-4 col-md-4 col-sm-3 col-xs-12">
                            <div class="form-example-int">
                                <button class="btn btn-success notika-btn-success waves-effect" type="submit" name="submit">Withdraw Amount</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br>
<!-- Statistics For User Rewards Start-->
<div class="notika-status-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="search-engine-int sm-res-mg-t-30 tb-res-mg-t-30 tb-res-ds-n dk-res-ds">
                    <div class="contact-hd search-hd-eg">
                        <h2>Withdrawal History</h2>
                        <p>My Wallet Rewards </p>
                    </div>
                    <div class="search-eg-table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>No#</th>
                                    <th>Request Date</th>
                                    <th>Approved Date</th>
                                    <th> Amount</th>
                                    <th>Status</th>
                                    <th class="text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>25-Mar-2020</td>
                                    <td>26-Mar-2020</td>
                                    <td>$100.88</td>
                                    <td>
                                        <button class="btn btn-success notika-btn-success btn-xs waves-effect">Approved</button>
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-primary notika-btn-primary btn-xs waves-effect">View</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>25-Mar-2020</td>
                                    <td>26-Mar-2020</td>
                                    <td>$100.88</td>
                                    <td>
                                        <button class="btn btn-success notika-btn-success btn-xs waves-effect">Approved</button>
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-primary notika-btn-primary btn-xs waves-effect">View</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>25-Mar-2020</td>
                                    <td>26-Mar-2020</td>
                                    <td>$100.88</td>
                                    <td>
                                        <button class="btn btn-danger notika-btn-danger btn-xs waves-effect">Rejected</button>
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-primary notika-btn-primary btn-xs waves-effect">View</button>
                                    </td>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>25-Mar-2020</td>
                                    <td>26-Mar-2020</td>
                                    <td>$100.88</td>
                                    <td>
                                        <button class="btn btn-info notika-btn-info btn-xs waves-effect">Pending</button>
                                    </td>
                                    <td class="text-right">
                                        <button class="btn btn-primary notika-btn-primary btn-xs waves-effect">View</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Statistics For User Rewards End-->
@endsection