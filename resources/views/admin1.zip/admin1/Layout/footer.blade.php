<div class="footer-copyright-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="footer-copy-right">
                    <p>Best Restaurant reservation interactive!{{--<a href="https://colorlib.com/wp/templates/">Colorlib</a>--}}</p>
                </div>
            </div>
        </div>
    </div>
</div>