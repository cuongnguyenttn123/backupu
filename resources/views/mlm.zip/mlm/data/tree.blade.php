@php
use App\Http\Controllers\UserController;
use App\Http\Controllers\MlmController;
@endphp
@extends('mlm.layout.layout2')
@section('content')
<style type="text/css">
.tree,
.tree ul,
.tree li {
    list-style: none;
    margin: 0;
    padding: 0;
    position: relative;
}

.tree {
    margin: 0 0 1em;
    text-align: center;
    width: 100%
}

.tree,
.tree ul {
    display: table;
}

.tree ul {
    width: 100%;
}

.tree li {
    display: table-cell;
    padding: .5em 0;
    vertical-align: top;
}

.tree li:before {
    outline: solid 1px #666;
    content: "";
    left: 0;
    position: absolute;
    right: 0;
    top: 0;
}

.tree li:first-child:before {
    left: 50%;
}

.tree li:last-child:before {
    right: 50%;
}

.tree code,
.tree span {
    /*border: solid .1em #666;*/
    border-radius: .2em;
    display: inline-block;
    margin: 0 .2em .5em;
    padding: .2em .5em;
    position: relative;
}

.tree ul:before,
.tree code:before,
.tree span:before {
    outline: solid 1px #666;
    content: "";
    height: .5em;
    left: 50%;
    position: absolute;
}

.tree ul:before {
    top: -.7em;
}

.tree code:before,
.tree span:before {
    top: -.4em;
}

.tree>li {
    margin-top: 0;
}

.tree>li:before,
.tree>li:after,
.tree>li>code:before,
.tree>li>span:before {
    outline: none;
}
img.img-fluid.rounded-circle.width-50{
    width: 60px !important;
    height: 60px;
}
</style>


<!-- BEGIN: Content-->
    <div class="app-content content">
      <div class="content-overlay"></div>
      <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">            
            <div class="row">
                <div id="recent-transactions" class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">My Team</h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                
                            </div>
                        </div>            
                        <div class="card-content">                
                            <div class="card-body">
            
                                <ul class="tree">
                                    <li><span data-toggle="tooltip" data-html="true" title=""><img src="{{ MlmController::getuser_name_img(Request::segment(2))}}" alt="" class="img-fluid rounded-circle width-50"></span>
                                <ul >

                                @foreach($sub_Child as $key => $value)
                            
                                <li><a target="_blank" href="{{url('user_mlmtree/').'/'.$value['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value['uid']) }}<br>Total Links : {{$value['totallink']}} <br> Type : {{$value['p_status']}}"><img src="{{ MlmController::getuser_name_img($value['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                @if(!empty($value['subchild']))
                                    
                                        @foreach($value['subchild'] as $key1 => $value1)
                                            <ul>
                                                <li>
                                                    <a target="_blank" href="{{url('user_mlmtree/').'/'.$value1['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value1['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value1['uid']) }}<br>Total Links : {{$value1['totallink']}} <br> Type : {{$value1['p_status']}}"><img src="{{ MlmController::getuser_name_img($value1['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                    <!-- 3rd -->
                                                    @if(!empty($value1['subchild']))
                                                        
                                                            @foreach($value1['subchild'] as $key2 => $value2)
                                                                <ul>
                                                                    <li>
                                                                        <a target="_blank" href="{{url('user_mlmtree/').'/'.$value2['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value2['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value2['uid']) }}<br>Total Links : {{$value2['totallink']}} <br> Type : {{$value2['p_status']}}"><img src="{{ MlmController::getuser_name_img($value2['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                                        <!-- 4th -->
                                                                        @if(!empty($value2['subchild']))
                                                                            
                                                                                @foreach($value2['subchild'] as $key3 => $value3)
                                                                                    <ul>
                                                                                        <li>
                                                                                            <a target="_blank" href="{{url('user_mlmtree/').'/'.$value3['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value3['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value3['uid']) }}<br>Total Links : {{$value3['totallink']}} <br> Type : {{$value3['p_status']}}"><img src="{{ MlmController::getuser_name_img($value3['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                                                            <!-- 5th -->
                                                                                            @if(!empty($value3['subchild']))
                                                                                                
                                                                                                    @foreach($value3['subchild'] as $key4 => $value4)
                                                                                                        <ul>
                                                                                                            <li>
                                                                                                                <a target="_blank" href="{{url('user_mlmtree/').'/'.$value4['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value4['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value4['uid']) }}<br>Total Links : {{$value4['totallink']}} <br> Type : {{$value4['p_status']}}"><img src="{{ MlmController::getuser_name_img($value4['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                                                                                <!-- 6th -->
                                                                                                                @if(!empty($value4['subchild']))
                                                                                                                    
                                                                                                                        @foreach($value4['subchild'] as $key5 => $value5)
                                                                                                                            <ul>
                                                                                                                                <li>
                                                                                                                                    <a target="_blank" href="{{url('user_mlmtree/').'/'.$value5['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value5['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value5['uid']) }}<br>Total Links : {{$value5['totallink']}} <br> Type : {{$value5['p_status']}}"><img src="{{ MlmController::getuser_name_img($value5['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                                                                                                    <!-- 7th -->
                                                                                                                                    @if(!empty($value5['subchild']))
                                                                                                                                        
                                                                                                                                            @foreach($value5['subchild'] as $key6 => $value6)
                                                                                                                                                <ul>
                                                                                                                                                    <li>
                                                                                                                                                        <a target="_blank" href="{{url('user_mlmtree/').'/'.$value6['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value6['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value6['uid']) }}<br>Total Links : {{$value6['totallink']}} <br> Type : {{$value6['p_status']}}"><img src="{{ MlmController::getuser_name_img($value6['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                                                                                                                        <!-- 8th -->
                                                                                                                                                        @if(!empty($value6['subchild']))
                                                                                                                                                            
                                                                                                                                                                @foreach($value6['subchild'] as $key7 => $value7)
                                                                                                                                                                    <ul>
                                                                                                                                                                        <li>
                                                                                                                                                                            <a target="_blank" href="{{url('user_mlmtree/').'/'.$value7['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value7['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value7['uid']) }}<br>Total Links : {{$value7['totallink']}} <br> Type : {{$value7['p_status']}}"><img src="{{ MlmController::getuser_name_img($value7['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                                                                                                                                            <!-- 9th -->
                                                                                                                                                                            @if(!empty($value7['subchild']))
                                                                                                                                                                                
                                                                                                                                                                                    @foreach($value7['subchild'] as $key8 => $value8)
                                                                                                                                                                                        <ul>
                                                                                                                                                                                            <li>
                                                                                                                                                                                                <a target="_blank" href="{{url('user_mlmtree/').'/'.$value8['uid']}}"><span data-toggle="tooltip" data-html="true" title="Refrence ID : {{$value8['uid']}} <br>Suponsered Name : {{ MlmController::getuser_name($value8['uid']) }}<br>Total Links : {{$value8['totallink']}} <br> Type : {{$value8['p_status']}}"><img src="{{ MlmController::getuser_name_img($value8['uid'])}}" alt="" class="img-fluid rounded-circle width-50"></span></a>
                                                                                                                                                                                            </li>
                                                                                                                                                                                        </ul>
                                                                                                                                                                                    @endforeach 
                                                                                                                                                                               
                                                                                                                                                                            @endif
                                                                                                                                                                        </li>
                                                                                                                                                                    </ul>
                                                                                                                                                                @endforeach 
                                                                                                                                                           
                                                                                                                                                        @endif
                                                                                                                                                    </li>
                                                                                                                                                </ul>
                                                                                                                                            @endforeach 
                                                                                                                                       
                                                                                                                                    @endif
                                                                                                                                </li>
                                                                                                                            </ul>
                                                                                                                        @endforeach 
                                                                                                                   
                                                                                                                @endif
                                                                                                            </li>
                                                                                                        </ul>
                                                                                                    @endforeach 
                                                                                               
                                                                                            @endif
                                                                                        </li>
                                                                                    </ul>
                                                                                @endforeach 
                                                                           
                                                                        @endif
                                                                    </li>
                                                                </ul>
                                                            @endforeach 
                                                       
                                                    @endif
                                                </li>
                                            </ul>
                                        @endforeach 
                                   
                                @endif
                                </li>
                            
                            @endforeach  
                            </ul>  
                            </li>
                            </ul>                       
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
      </div>
    </div>

    
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>
@endsection